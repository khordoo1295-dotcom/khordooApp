قطعات بتنی خردو - بسته ساخت GitHub

1) فایل KhorodoSource.zip را در ریشه مخزن GitHub آپلود کنید.
2) در GitHub از Add file > Create new file استفاده کنید.
3) نام فایل را این‌طور وارد کنید:
   .github/workflows/build-apk.yml
4) محتویات فایل build-apk.yml همین بسته را داخل آن قرار دهید و Commit کنید.
5) از Actions > Build Khorodo APK > Run workflow اجرا کنید.
6) بعد از اتمام، از بخش Artifacts فایل Khorodo-debug-apk را دانلود کنید.
